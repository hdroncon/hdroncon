# html_example
Web pages written in HTML to test functionalities and tools related with this type of markup language.

Open the index.html file to play around.
