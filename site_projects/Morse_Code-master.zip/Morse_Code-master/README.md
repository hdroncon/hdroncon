# Morse_Code
A simple english-to-morsecode translator using Python.
