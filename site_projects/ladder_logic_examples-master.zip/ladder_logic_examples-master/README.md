# ladder_logic_examples
Random problems solved using ladder logic. 
I have used the WEG CLIC02 (v3.3) software to write these programs, a free software that can be downloaded here:
http://www.weg.net/br/Produtos-e-Servicos/Drives/CLPs-e-Controle-de-Processos/CLIC02
