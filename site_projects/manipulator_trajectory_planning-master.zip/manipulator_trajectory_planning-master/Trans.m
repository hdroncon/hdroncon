function [ saida ] = Trans( x,y,z )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

saida = [ 1 0 0 x; 0 1 0 y; 0 0 1 z; 0 0 0 1]; 

end

