# manipulator_trajectory_planning
Given specific coordinates and velocities that the robot must perform, calculates the TRR robot arm TCP and joints trajectories, velocities and accelerations.

A4_test is the main file, run it to get values and plots.
