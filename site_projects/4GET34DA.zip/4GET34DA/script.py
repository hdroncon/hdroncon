import eel
import sqlite3
from fpdf import FPDF
from datetime import datetime

eel.init('web') # Give folder containing web files

@eel.expose # Expose this function to Javascript
def handleinput2(x):
    # Connect to the database and create a cursor
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("""UPDATE proposal SET cst_name=? WHERE proposal_id=2;""", (x,))
    c.execute("SELECT * FROM proposal")
    print(c.fetchall())
    conn.commit()
    # Close database connection
    conn.close()
    print('oioioi %s' % x)

@eel.expose # Expose this function to Javascript
def allvals(v01, v02, v03, v04, v05, v06, v07, v08, v09, v10, v11, v12, v13):
    valsHtml = [v01, v02, v03, v04, v05, v06, v07, v08, v09, v10, v11, v12, v13]
    convHtml = lambda i : i or 0
    resHtml = [convHtml(i) for i in valsHtml]
    resHtml[7] = int(resHtml[7])
    resHtml[10] = str(resHtml[10])
    resHtml[11] = str(resHtml[11])
    resHtml[12] = str(resHtml[12])
    # Connect to the database and create a cursor
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("""INSERT INTO proposal (t_date, model_type, ac_drive, ac_electric, ac_wheels, ac_breaks, ac_glass, track_day, radio_type, pack_name, obs_sell, cst_name, cst_mail, cst_phone) VALUES (datetime('now'), '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')""" % (resHtml[2], resHtml[3], resHtml[6], resHtml[5], resHtml[4], resHtml[7], resHtml[8], resHtml[12], resHtml[9], resHtml[10], resHtml[1], resHtml[0], resHtml[11]))
    conn.commit()
    conn.close()
    
@eel.expose # Expose this function to Javascript
def getPDF():
    # Variables
    m = 10 # Margin
    pw = 210 - 2*m # Page width: Width of A4 is 210mm
    ch = 50 # Cell height
    dataT = datetime.today().strftime('%d-%m-%Y') #date

    # Custom class to overwrite the header and footer methods
    class PDF(FPDF):
        def header(self):
            self.set_font('Arial', 'I', 12)
            self.image('web/images/logo-black.png', x = 20, y = 10, w=30)
            self.cell(140)
            self.cell(w=50, h=6, txt='HRCars | Cars for People', border=0, ln=1, align ='L')
            self.cell(140)
            self.set_font('Arial', '', 12)
            self.cell(w=50, h=6, txt="A formal Invoice", border=0, ln=1, align ='L')
            self.cell(140)
            self.cell(w=50, h=6, txt="Date: " + dataT, border=0, ln=1, align ='L')
            self.cell(w=pw, h=12, ln=1)
            #self.image('logo-black.png', x = 210-50, y = None, w = 0, h = 30)

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 12)
            self.cell(w=(pw/3), h=10, txt='HRoncon', border=0, ln=0, align ='L')
            self.set_font('Arial', '', 12)
            self.cell(w=(pw/3), h=10, txt='cvhroncon.com.br', border=0, ln=0, align ='C')
            self.cell(w=(pw/3), h=10, txt='FPDF', border=0, ln=0, align ='R')

    # Get last entry into the invoice/proposal table
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("SELECT * FROM proposal ORDER BY proposal_id DESC LIMIT 1;")
    lastData = c.fetchone()
    conn.commit()
    conn.close()
    proposalId = lastData[0]
    # proposalDate = lastData[1]
    # proposalModel = lastData[2]
    proposalAcdrive = lastData[3]
    proposalAcelec = lastData[4]
    proposalAcwheel = lastData[5]
    proposalAcbreak = lastData[6]
    proposalGlass = lastData[7]
    proposalTday = lastData[8]
    # proposalRadio = lastData[9]
    # proposalPack = lastData[10]
    proposalObs = lastData[11]
    proposalName = lastData[12]
    proposalMail = lastData[13]
    proposalPhone = lastData[14]
    
    # Get info from models table
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("SELECT proposal.model_type, models.name_correct,  models.displacement, models.horsepower, models.torque, models.price FROM proposal INNER JOIN models ON proposal.model_type=models.model_name;")
    lastData2 = c.fetchall()
    conn.commit()
    conn.close()
    lastData2 = lastData2[proposalId-1]
    modelName = lastData2[1]
    modelDisp  = lastData2[2]
    modelHp = lastData2[3]
    modelTq = lastData2[4]
    modelPc = lastData2[5]
    

    # Get info from radio table
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("SELECT proposal.radio_type, radios.name_correct, radios.subwoofer, radios.front_speakers, radios.back_speakers, radios.price FROM proposal INNER JOIN radios ON proposal.radio_type=radios.radio_name;")
    lastData3 = c.fetchall()
    conn.commit()
    conn.close()
    lastData3 = lastData3[proposalId-1]
    radioName = lastData3[1]
    radiSwf = lastData3[2]
    radioFs = lastData3[3]
    radioBs = lastData3[4]
    radioPc = lastData3[5]
    
    radioStats = [radiSwf, radioFs, radioBs]
    radioAtt = ["Subwoofer", "Front speakers", "Back speakers"]
    radioState = [radioAtt[idx] if radioStats[idx] != 0 else "remove" for idx in range(len(radioStats))]
    radioStatenew = [i for i in radioState if i != "remove"]
    radioStateStr = '; '.join(map(str, radioStatenew))
    

    # Get info from packages table
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("SELECT proposal.pack_name, packages.name_correct, packages.enhanced_sg, packages.live_traffic, packages.blind_spot, packages.power_mirror, packages.speed_limit, packages.keyless, packages.seat_memory, packages.touchscreen, packages.speed_adpt, packages.active_emer, packages.price FROM proposal INNER JOIN packages ON proposal.pack_name=packages.pack_name;")
    lastData4 = c.fetchall()
    conn.commit()
    conn.close()
    lastData4 = lastData4[proposalId-1]
    packName = lastData4[1]
    packEsg = lastData4[2]
    packLt = lastData4[3]
    packBs = lastData4[4]
    packPm = lastData4[5]
    packSl = lastData4[6]
    packKl = lastData4[7]
    packSm = lastData4[8]
    packTs = lastData4[9]
    packSa = lastData4[10]
    packAe = lastData4[11]
    packPr = lastData4[12]

    packStats1 = [packEsg, packLt, packBs]
    packAtt1 = ["Enhanced Stop-and-Go", "Live Traffic Service", "Blind Spot Assist"]
    packStats2 = [packPm, packSl, packKl]
    packAtt2 = ["Power-folding side mirrors", "Active Speed Limit Assist", "KEYLESS-GO"]
    packStats3 = [packSm, packTs]
    packAtt3 = ["Power front passenger seat with memory", "10.25-inch touchscreen centre multimedia display"]
    packStats4 = [packSa, packAe]
    packAtt4 = ["Route-based Speed Adaptation", "Active Emergency Stop Assist"]
    packState1 = [packAtt1[idx] if packStats1[idx] != 0 else "remove" for idx in range(len(packStats1))]
    packState2 = [packAtt2[idx] if packStats2[idx] != 0 else "remove" for idx in range(len(packStats2))]
    packState3 = [packAtt3[idx] if packStats3[idx] != 0 else "remove" for idx in range(len(packStats3))]
    packState4 = [packAtt4[idx] if packStats4[idx] != 0 else "remove" for idx in range(len(packStats4))]
    packStatenew1 = [i for i in packState1 if i != "remove"]
    packStatenew2 = [i for i in packState2 if i != "remove"]
    packStatenew3 = [i for i in packState3 if i != "remove"]
    packStatenew4 = [i for i in packState4 if i != "remove"]
    packStateStr1 = '; '.join(map(str, packStatenew1))
    packStateStr2 = '; '.join(map(str, packStatenew2))
    packStateStr3 = '; '.join(map(str, packStatenew3))
    packStateStr4 = '; '.join(map(str, packStatenew4))
    
    # Get info from accessories table
    conn = sqlite3.connect('web/db/hrdealer.db')
    c = conn.cursor()
    c.execute("SELECT * FROM accessories;")
    lastData5 = c.fetchall()
    conn.commit()
    conn.close()
    accElc = lastData5[0][2]
    accWhl = lastData5[1][2]
    accBrk = lastData5[2][2]
    accGls = lastData5[3][2]
    accTdy = lastData5[4][2]
    accDrv = lastData5[5][2]

    accPrices = [accElc*proposalAcelec, accWhl*proposalAcwheel, accBrk*proposalAcbreak, int(accGls*(proposalGlass/100)), accTdy*proposalTday, accDrv*proposalAcdrive]
    accState = ["Not included" if accPrices[idx] == 0 else "Included" for idx in range(len(accPrices))]
    
    # Total price
    fullPrice = modelPc + radioPc + packPr + sum(accPrices)
    
    # Create invoice
    pdf = PDF() # Instance of custom class
    pdf.add_page()
    pdf.cell(w=0, h=5, border="B", ln=1)
    pdf.set_font('Arial', '', 12)
    pdf.cell(w=0, h=2, ln=1)
    pdf.cell(w=0, h=5, txt = "Proposal number " + str(proposalId) + " for:", border=0, ln=1, align ='L')
    pdf.cell(w=0, h=5, txt = proposalName, border=0, ln=1, align ='L')
    pdf.cell(w=0, h=5, txt = "Mail: " + proposalMail, border=0, ln=1, align ='L')
    pdf.cell(w=0, h=5, txt="Phone: " + proposalPhone, border=0, ln=1, align ='L')
    pdf.cell(w=0, h=2, ln=1)

    pdf.set_font('Arial', 'B', 12)
    pdf.set_fill_color(200,30,30)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(w=pw*.8, h=8, txt = "Model Specs", fill = True, border="B", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=8, txt = "Value", fill = True, border="B", ln=1, align ='C')
    pdf.set_font('Arial', '', 12)
    pdf.set_text_color(0, 0, 0)
    pdf.cell(w=pw*.8, h=7, txt = modelName, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(modelPc), border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Displacement (L): " + modelDisp + " , HP: " + str(modelHp) + ", Torque (Nm): " + str(modelTq), border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", ln=1, align ='C')
    pdf.set_fill_color(242,242,242)
    pdf.cell(w=pw*.8, h=7, txt="Driving Assistance: " + accState[5], border="L", fill = True, ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[5]), border="R",fill = True,  ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Breaking Assistance: " + accState[2], border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[2]), border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Gearbox: " + accState[1], border="L", fill = True, ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[1]), border="R",fill = True,  ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Electricity: " + accState[0], border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[0]), border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Window Tint: " + accState[3], border="L", fill = True, ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[3]), border="R",fill = True,  ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Track day: " + accState[4], border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(accPrices[4]), border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Radio: " + radioName, border="L", fill = True, ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(radioPc), border="R",fill = True,  ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Included: " + radioStateStr, border="L", fill = True, ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", fill = True, ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Package: " + packName, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(packPr) + "/month", border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt="Features: " + packStateStr1, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt=packStateStr2, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt=packStateStr3, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", ln=1, align ='C')
    pdf.cell(w=pw*.8, h=7, txt=packStateStr4, border="L", ln=0, align ='L')
    pdf.cell(w=pw*.2, h=7, border="R", ln=1, align ='C')
    pdf.cell(w=pw, h=4, border="T", ln=1)

    pdf.set_font('Arial', 'B', 12)
    pdf.set_text_color(200,30,30)
    pdf.cell(w=pw*.8, h=7, txt="Total", ln=0, align ='R')
    pdf.cell(w=pw*.2, h=7, txt="$ " + str(fullPrice), ln=1, align ='C')
    pdf.cell(w=pw, h=20, ln=1)

    pdf.set_font('Arial', 'B', 12)
    pdf.set_fill_color(200,30,30)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(w=pw, h=8, txt="Notes", fill = True, border="B", ln=1, align ='L')
    pdf.set_font('Arial', '', 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(w=pw, h=7, txt = proposalObs, border = 1, align = 'J')
    pdf.cell(w=pw, h=8, ln=1)
    invoiceName = 'web/invoice/invoice_' + str(proposalId) +'.pdf'
    pdf.output(invoiceName, 'F')


# eel.say_hello_js('connected!')   # Call a Javascript function

eel.start('main.html')    # Start
