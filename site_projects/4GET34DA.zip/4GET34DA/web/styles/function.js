$(function(){

    $("#btn").click(function(){
        var var1 = $("#email").val();
        var var2 = $("#name").val();
        var var3 = $("input[type='radio'][name='carmodel']:checked").val();
        var var4 = $("input[type='checkbox'][name='acdrive']:checked").val();
        var var5 = $("input[type='checkbox'][name='acbrakes']:checked").val();
        var var6 = $("input[type='checkbox'][name='acgear']:checked").val();
        var var7 = $("input[type='checkbox'][name='acelect']:checked").val();
        var var8 = $("#addontint").val();
        var var9 = $("input[type='checkbox'][name='addtrack']:checked").val();
        var var10 = $("input[type='radio'][name='carpackage']:checked").val();
        var var11 = $("#carnotes").val();
        var var12 = $("#phone").val();
        var var13 = $("#addradioopt").val();
        // var var4 = $("#modelbhd").val();
        // eel.handleinput(var1, var2);
        // eel.handleinput2(var3);
        eel.allvals(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13);
        eel.getPDF();
        // $('#name').val('');
        // $('#email').val('');
        // eel.handleinput2($("#email").val());
        // $('#email').val('');
    });
}); 

function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}


function toggleSelect()
{
  var isChecked = document.getElementById("addradio").checked;
  document.getElementById("addradioopt").disabled = !isChecked;
  selectDefault()
}

function selectDefault() {
    if (document.getElementById("addradio").checked == false) {
       document.getElementById("addradioopt").value = "default";
    }
  }