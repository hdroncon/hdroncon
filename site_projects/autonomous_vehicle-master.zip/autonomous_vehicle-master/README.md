# autonomous_vehicle

Using arduino and a GPS device, the platform - auxiliated by servomotors - goes from an initial random start point to a second (then third, then fourth and so on, if desired) point, previously programmed into the code.
