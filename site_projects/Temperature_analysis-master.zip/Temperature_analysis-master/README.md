# Temperature_analysis
Maps (manually) the minimum and maximum temperatures forecast using webscrape.
